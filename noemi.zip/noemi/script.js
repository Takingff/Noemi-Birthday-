const birthdayItaly = new Date("2025-03-02T00:00:00+01:00");

const text = 
"Today is special because YOU were born ❤️\n\n" +
"You are my smile, my peace, my favorite thought 💕\n\n" +
"Every memory with you is a treasure 📸✨\n\n" +
"Happy Birthday my love, forever yours 💖";

let i = 0;
let photos = [
  "images/1.jpg",
  "images/2.jpg",
  "images/3.jpg",
  "images/4.jpg",
  "images/5.jpg",
  "images/6.jpg",
  "images/7.jpg",
  "images/8.jpg",
  "images/9.jpg"
];
let index = 0;

function startSurprise() {
  document.querySelector(".overlay").style.display = "none";
  document.querySelector(".container").classList.remove("hidden");

  const music = document.getElementById("bgMusic");
  music.volume = 0.8;
  music.currentTime = 0;
  music.play().catch(() => {
    alert("Tap once anywhere to start the music 💕");
  });

  typeText();
  slideshow();
}

function typeText() {
  if (i < text.length) {
    document.getElementById("typing").innerHTML +=
      text[i] === "\n" ? "<br>" : text[i];
    i++;
    setTimeout(typeText, 60);
  }
}

function slideshow() {
  const img = document.getElementById("photo");
  setInterval(() => {
    img.src = photos[index];
    index = (index + 1) % photos.length;
  }, 2500);
}

document.addEventListener("click", e => {
  if (e.target.id === "flame") {
    e.target.innerHTML = "💨";
    alert("Wish accepted 💖 — Abir");
  }
});
// Countdown Timer
function countdown() {
    const now = new Date();
    const birthday = new Date(now.getFullYear(), 2, 2); // March is 2 because Jan=0
    if (now > birthday) {
        birthday.setFullYear(now.getFullYear() + 1);
    }
    const diff = birthday - now;

    const days = Math.floor(diff / (1000*60*60*24));
    const hours = Math.floor((diff / (1000*60*60)) % 24);
    const minutes = Math.floor((diff / (1000*60)) % 60);
    const seconds = Math.floor((diff / 1000) % 60);

    document.getElementById('countdown').innerText =
        `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

setInterval(countdown, 1000);
countdown();
